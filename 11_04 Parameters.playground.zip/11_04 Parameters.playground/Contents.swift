// An exercise file for iOS Development Tips Weekly
// A weekly course on LinkedIn Learning for iOS developers
//  Season 11 (Q3 2020) video 04
//  by Steven Lipton (C)2020, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
//This Week:  Look deeper into the world of function parameters
//  For more code, go to http://bit.ly/AppPieGithub

import UIKit


func volume(_ diameter:Double,height a:Double = 0.25) -> Double{
    let pi = Double.pi
    let z = diameter / 2.0
    return pi * z * z * a
}

func totalVolume(_ diameters:Double...,height a:Double = 0.25) -> Double{
    let pi = Double.pi
    var t = 0.0
    for diameter in diameters{
        let z = diameter / 2.0
        t += pi * z * z * a
    }
    return t
}

func addPizza(_ diameter:Double,volume: inout Double,height a:Double = 0.25) -> Double{
    let pi = Double.pi
  
   
        let z = diameter / 2.0
        let v =  pi * z * z * a
    volume += v
    
    return v
}
volume(10,height:2)
volume(10)
totalVolume(10,10, height: 2)
var vol = 0.0
addPizza(10, volume: &vol, height: 2)
addPizza(10, volume: &vol, height: 2)
vol
